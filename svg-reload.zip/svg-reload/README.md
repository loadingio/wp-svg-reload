# Wordpress SVG Reload

add random hash in SVG url to prevent cache. Used for restart SVG animation.


## License

GPLv2
